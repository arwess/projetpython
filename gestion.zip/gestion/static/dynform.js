var id = document.getElementById('id')
var id_nom = document.getElementById(id_nom)

id_nom.style.dysplay = 'IN'
id_genre.onchange= function(){
    console.log(id_genre.value)
    id_nom.style.dysplay = 'block'
}
