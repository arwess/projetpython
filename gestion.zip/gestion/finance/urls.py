from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.info, name='enregistrement'),
    url(r'^info/$', views.info, name='enregistrement'),   
    url(r'^index', views.index, name='index'),
    url(r'^liste/(?P<ide>[0-9]+)$', views.liste, name='liste'),


    # url(r'^enregistrement1', views.enregistrement1, name='enregistrement1'),
    
]