from django import forms
from .models import Enregistrement
def controle(forms.ModelForm):
    class Meta:
        model = Enregistrement
        fields = [
            ('IN', 'Indivuduel.'),
            ('GIE', 'GIE.'),
            ('SA', 'SA.'),
            ('SAS', 'SAS.'),
            ('SARL', 'SARL.'),
            ('AUTRE', 'AUTRE.'),
        ]
    