# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.forms import ModelChoiceField
from django.forms import ModelForm
from django import forms


### Création des enregistrements (les champs du formulaire) ###
class Enregistrement(models.Model):
    TITLE_CHOICES = [
        ('IN', 'Indivuduel.'),
        ('GIE', 'GIE.'),
        ('SA', 'SA.'),
        ('SAS', 'SAS.'),
        ('SARL', 'SARL.'),
        ('AUTRE', 'AUTRE.'),
    ]
    genre = models.CharField(max_length=6, choices=TITLE_CHOICES)
    nom=models.CharField(max_length=200, unique=False)
    rc= models.CharField(max_length=200, unique=True)
    ninea= models.CharField(max_length=200, unique=True)
    tel= models.CharField(max_length=200, unique=False)
    activite= models.CharField(max_length=200, unique=False)
    nomrespo= models.CharField(max_length=200, unique=False)
    adresse= models.CharField(max_length=200, unique=False)
    telrespo= models.CharField(max_length=200, unique=False)
    qr= models.CharField(max_length=200, unique=False)
    logo= models.ImageField(upload_to=None, height_field=None, width_field=None, max_length=100)
    

    # nom_responsable=models.CharField(max_length=200, unique=False)
    # prenomnom_responsable=models.CharField(max_length=200, unique=False)
    # telephone=models.CharField(max_length=200, unique=False)
    
    ### recuperation des enregistrements ###
    
    def __str__(self):
        return self.nom

    
